<footer class="container-fluid desktopShow" style="background-color:#353535">
	
	
     	<div class="row" style="background-color: #353535; padding-top: 5rem">
			<div class="col-4"></div>
			<div class="col-4 text-center"><img width="200rem" src="<?php echo(base_url());?>images/logo.svg"> </div>
			<div class="col-4"></div>
		</div>
	
	  <div class="row" style="background-color: #353535; padding-top: 5rem; padding-bottom: 4rem; color: white; font-size: 1.3rem">
		
	
	  	<div class="col-1"></div>
		<div class="col-4" >
			<p style="font-size: 0.9rem; font-weight: bold">CONTACTO</p>
			<p style="font-size: 1rem; color: #c9c9c9"><img width="30rem" style="margin-right: 1rem" src="<?php echo(base_url());?>images/Telefono.svg">PBX: (02) 382 9070</p> 
			<p style="font-size: 1rem"><img width="30rem" style="margin-right: 1rem" src="<?php echo(base_url());?>images/Email.svg"><a class="footerLink" href="mailto:comercial@megaecuador.com">comercial@megaecuador.com</a></p>  
		</div>
		
		<div class="col-3" >
			<div style="padding-left: 2rem" style="background-color: aqua;">
				<p style="font-size: 0.9rem; font-weight: bold">ACERCA DE NOSOTROS</p>
				<p><a class="footerLink" href="<?php echo(base_url());?>index.php/welcome">Inicio</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/quienes">Quiénes Somos</a> </p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">Visítenos</a> </p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/contactenos" >Contáctenos</a> </p> 
			</div>
		  </div>
		
		<div class="col-3" >
			<div style="padding-left: 0.5rem">
				<p style="font-size: 0.9rem; font-weight: bold">PRODUCTOS</p>
				<p><a class="footerLink" href="<?php echo(base_url());?>index.php/papelCarton">Línea Papel Cartón</a></p>
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/chrysal">Línea Chrysal</a></p>
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/empaque">Línea Empaque</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/limpieza">Línea Limpieza Higiene</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/industrial">Línea Seguridad Industrial</a> </p> 
			</div>
		  </div>
		<div class="col-1"></div> 
	  </div>
	
	
     	<div class="row" style="background-color: #353535; padding-top: 2rem; padding-bottom: 2rem; border-top: 1px solid #6b6b6b">
			<div class="col-4"></div>
			<div class="col-4" style=" text-align: center">
			
				<ul style="list-style-type: none">
					<li style="display: inline-block; margin-left: -7rem"><a class="facebookIcon"  href="https://www.facebook.com/megastockec" target="_blank"> <img  width="30rem" src="<?php echo(base_url());?>images/Facebook.svg"></a></li>
					<li style="display: inline-block; padding-left: 5rem"><a class="InstagramIcon"  href="https://www.instagram.com/megastock_megaecuador/" target="_blank"> <img width="30rem" src="<?php echo(base_url());?>images/Instagram.svg"> </a></li>
					<li style="display: inline-block; padding-left: 5rem"><a class="WhatsappIcon"  href="https://bit.ly/3adVRmh" target="_blank"> <img width="30rem" src="<?php echo(base_url());?>images/Whatsapp.svg"></a></li>
				</ul>
				
			</div>
			<div class="col-4"></div>
		</div>
	
	
	  <div class="row" style="background-color: #000000; border-top: 1px solid #6b6b6b">
	  	<div class="col-4"></div>
		 <div class="col-4" style="color: white; font-size: 1rem; padding-top: 1rem; padding-bottom: 1rem; text-align: center">© Copyright Megastock 2021</div>
		  <div class="col-4"></div>
	  </div>
	  
  </footer>
	
	
<div class="row mobileShow">
	<footer class="container-fluid " style="background-color: #353535; padding-top: 1rem; padding-bottom: 1rem; color: white; font-size: 1.3rem">
		<div class="row" style="background-color: #353535; padding-top: 1rem">
			<div class="col-1"></div>
			<div class="col-6" ><img width="150rem" src="<?php echo(base_url());?>images/logo.svg"> </div>
			<div class="col-5"></div>
		</div>
		
		 <div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
		
		<div class="row" style="background-color: #353535; padding-top: 1rem">
			<div class="col-1"></div>
			<div class="col-10" >
				<p style="font-size: 0.9rem; font-weight: bold">CONTACTO</p>
				<p style="font-size: 1rem; color: #c9c9c9"><img width="30rem" style="margin-right: 1rem" src="<?php echo(base_url());?>images/Telefono.svg">PBX: (02) 382 9070</p> 
				<p style="font-size: 1rem"><img width="30rem" style="margin-right: 1rem" src="<?php echo(base_url());?>images/Email.svg"><a class="footerLink" href="mailto:comercial@megaecuador.com">comercial@megaecuador.com</a></p>  
			
			</div>
			<div class="col-1"></div>
		</div>
		
		 <div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
		
		<div class="row" style="background-color: #353535; padding-top: 1rem">
			<div class="col-1"></div>
			<div class="col-7" >
				
				<p style="font-size: 0.9rem; font-weight: bold">ACERCA DE NOSOTROS</p>
				<p><a class="footerLink" href="<?php echo(base_url());?>index.php/welcome">Inicio</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/quienes">Quiénes Somos</a> </p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">Visítenos</a> </p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/contactenos">Contáctenos</a> </p> 
			
			</div>
			<div class="col-4"></div>
		</div>
		
		 <div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
				
		<div class="row" style="background-color: #353535; padding-top: 1rem">
			<div class="col-1"></div>
			<div class="col-7" >
				
				<p style="font-size: 0.9rem; font-weight: bold">PRODUCTOS</p>
				<p><a class="footerLink" href="<?php echo(base_url());?>index.php/papelCarton">Línea Papel Cartón</a></p>
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/chrysal">Línea Chrysal</a></p>
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/empaque">Línea Empaque</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/limpieza">Línea Limpieza Higiene</a></p> 
				<p style="margin-top: -1rem"><a class="footerLink" href="<?php echo(base_url());?>index.php/industrial">Línea Seguridad Industrial</a> </p> 
			
			</div>
			<div class="col-4"></div>
		</div>
		
			 <div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
		<div class="row" style="background-color: #353535; padding-top: 1rem; padding-bottom: 1rem;">
			<div class="col-2"></div>
			<div class="col-8" style=" text-align: center">
			
				<ul style="list-style-type: none">
					<li style="display: inline-block; text-align: center"><a class="facebookIcon"  href="https://www.facebook.com/megastockec" target="_blank"> <img  width="30rem" src="<?php echo(base_url());?>images/Facebook.svg"></a></li>
					<li style="display: inline-block; padding-left: 3rem"><a class="InstagramIcon"  href="https://www.instagram.com/megastock_megaecuador/" target="_blank"> <img width="30rem" src="<?php echo(base_url());?>images/Instagram.svg"> </a></li>
					<li style="display: inline-block; padding-left: 3rem"><a class="WhatsappIcon"  href="https://bit.ly/3adVRmh" target="_blank"> <img width="30rem" src="<?php echo(base_url());?>images/Whatsapp.svg"></a></li>
				</ul>
				
			</div>
			<div class="col-2"></div>
		</div>
	
	<div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
	  <div class="row" >
	  	<div class="col-2"></div>
		 <div class="col-8" style="color: white; font-size: 1rem; padding-top: 1rem; padding-bottom: 0rem; text-align: center">© Copyright Megastock 2021</div>
		  <div class="col-2"></div>
	  </div>
		
	
	</footer>
</div>

</main>
</html>