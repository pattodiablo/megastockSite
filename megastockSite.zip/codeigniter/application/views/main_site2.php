<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

</header>

<main role="main" style="display:none;" id="myDiv">
	
<div class="fill" >
  
  <div class="carouselContainer" > 

    <div id="myCarousel" class="carousel carousel-fade" data-interval="6500" data-ride="carousel">
      
      <div class="carousel-inner">

        <div class="carousel-item active" >
			<!-- Colocar desde aqui texto repetido del ultimo banner  -->
					  <div class="anchoFranja" style="position: relative; top: 0%; left: 0%; overflow: hidden;  background-color:#9163a6;">
						<div  style="background-color: #ffa400">
						  <div class="desapareceTexto" style="transform: translateY(-15%);"  >

							  <p class="tamanoTextoProducto2" >Línea</p>
							  <h1 class="tamanoTextoProducto" >Seguridad Industrial</h1>
							  <p class="tamanoTextoProducto3" >Prevención de Riesgos</p>
							  <p class="margenBoton"><a id="firstBoton"  class="botonBlanco " href="<?php echo(base_url());?>index.php/industrial">+ VER MÁS</a></p>

						  </div>
						</div>
					  </div>
			<!-- Colocar hasta aqui texto repetido del ultimo banner  --> 

					  <div class="colorBanner anchoFranja" style="position: relative; top: -100%; left: 0%; overflow: hidden;   background-color:white;">
					  <div class="animatedBanner3" style="background-color: #ffa400">
					  <div class="textoInterior" style="transform: translateY(-15%);"  >
						  
								  <p class="tamanoTextoProducto2" >Línea</p>
								  <h1  class="tamanoTextoProducto">Papel Cartón</h1>
								  <p class="tamanoTextoProducto3" >Calidad de Producción</p>
								  <p class="margenBoton"><a style="color: #ffa400 " class="botonBlanco" href="<?php echo(base_url());?>index.php/papelCarton">+ VER MÁS</a></p>

					  </div>
					   </div>
					  </div>
					  <div class="container">

						<div class="carousel-caption" >
							<div class="innerBannerContainer">
							  <div class="animatedBanner2" >
								<img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_1B.jpg" >
							<img class="desaparece" style="transform-origin: center center; width: 100%; transform: translateY(-150%); " src="<?php echo(base_url());?>images/Banner_1A.jpg" >

						</div>
					  </div>
					</div>

				<!-- Colocar desde aqui la imagen repetida del ultimo banner  -->
					<div class="carousel-caption" >
					  <div class="innerBannerContainer">
						<div class="animatedBanner4" style="visibility: hidden;" >
						  <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_5B.jpg" >
				  </div>
				</div>
			  </div>
			  <!-- Colocar hasta aqui la imagen repetida del ultimo banner  -->

					  </div>
        </div>
        
		<div class="carousel-item " >
<!-- Colocar desde aqui texto repetido del banner anterior -->
          <div class="anchoFranja" style="position: relative; top: 0%; left: 0%; overflow: hidden;   background-color:#ffa400;">
              <div class="" style="background-color: #ffa400">
                <div class="desapareceTexto" style="transform: translateY(-15%);"  >
                
                    <p class="tamanoTextoProducto2">Línea</p>
                    <h1 class="tamanoTextoProducto">Papel Cartón</h1>
                    <p class="tamanoTextoProducto3">Calidad de Producción</p>
                     <p class="margenBoton"><a style="color: #ffa400 " class="botonBlanco" href="<?php echo(base_url());?>index.php/papelCarton">+ VER MÁS</a></p>
            
                </div>
              </div>
            </div>
  <!-- Colocar hasta aqui texto repetido del banner anterior -->    

          <div class="anchoFranja" style="position: relative; top: -100%; left: 0%; overflow: hidden; background-color:transparent;"> <!-- background transparente para dejar ver el texto anterior -->  
            <div class="animatedBanner3" style="background-color:#527bbd">
              <div class="textoInterior" style="transform: translateY(-15%);"  >
                
                <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Chrysal</h1>
                <p class="tamanoTextoProducto3">Distribuidor en Ecuador</p>
                 <p class="margenBoton"><a style="color: #527bbd " class="botonBlanco" href="<?php echo(base_url());?>index.php/chrysal">+ VER MÁS</a></p>
                
              </div>
               </div>
          </div>
          
          
          <div class="container">
                      
            <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  
                  <div class="animatedBanner2" >
                    
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_2B.jpg" >
                <img class="desaparece" style="transform-origin: center center; width: 100%; transform: translateY(-150%); " src="<?php echo(base_url());?>images/Banner_2A.jpg" >
                
            </div>
          </div>
        </div>
 <!-- Colocar desde aqui imagen repetida del anterior banner -->  
         <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  <div class="animatedBanner4" >
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_1B.jpg" >
            </div>
          </div>
        </div>
<!-- Colocar hasta aqui imagen repetida del anterior banner -->        
          </div>
        </div>
		  
        <div class="carousel-item " >
<!-- Colocar desde aqui texto repetido del banner anterior -->
          <div class="anchoFranja" style="position: relative; top: 0%; left: 0%; overflow: hidden;   background-color:#527bbd;">
              <div class="" style="background-color: #ffa400">
                <div class="desapareceTexto" style="transform: translateY(-15%);"  >
                
                     <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Chrysal</h1>
                <p class="tamanoTextoProducto3">Distribuidor en Ecuador</p>
                 <p class="margenBoton"><a style="color: #527bbd " class="botonBlanco" href="<?php echo(base_url());?>index.php/chrysal">+ VER MÁS</a></p>
            
                </div>
              </div>
            </div>
  <!-- Colocar hasta aqui texto repetido del banner anterior -->    

          <div class="anchoFranja" style="position: relative; top: -100%; left: 0%; overflow: hidden; background-color:transparent;"> <!-- background transparente para dejar ver el texto anterior -->  
            <div class="animatedBanner3" style="background-color:#808285">
              <div class="textoInterior" style="transform: translateY(-15%);"  >
                
                <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Empaque</h1>
                <p class="tamanoTextoProducto3">Importadores Directos</p>
                 <p class="margenBoton"><a style="color: #808285 " class="botonBlanco" href="<?php echo(base_url());?>index.php/empaque">+ VER MÁS</a></p>
                
              </div>
               </div>
          </div>
          
          
          <div class="container">
                      
            <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  
                  <div class="animatedBanner2" >
                    
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_3B.jpg" >
                <img class="desaparece" style="transform-origin: center center; width: 100%; transform: translateY(-150%); " src="<?php echo(base_url());?>images/Banner_3A.jpg" >
                
            </div>
          </div>
        </div>
 <!-- Colocar desde aqui imagen repetida del primer banner -->  
         <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  <div class="animatedBanner4" >
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_2B.jpg" >
            </div>
          </div>
        </div>
<!-- Colocar hasta aqui imagen repetida del primer banner -->        
          </div>
        </div>

	
		 <div class="carousel-item " >
<!-- Colocar desde aqui texto repetido del banner anterior -->
          <div class="anchoFranja" style="position: relative; top: 0%; left: 0%; overflow: hidden;   background-color:#808285;">
              <div class="" style="background-color: #ffa400">
                <div class="desapareceTexto" style="transform: translateY(-15%);"  >
                
                     <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Empaque</h1>
                <p class="tamanoTextoProducto3">Importadores Directos</p>
                  <p class="margenBoton"><a  style="color: #808285 " class="botonBlanco" href="<?php echo(base_url());?>index.php/empaque">+ VER MÁS</a></p>
            
                </div>
              </div>
            </div>
  <!-- Colocar hasta aqui texto repetido del banner anterior -->    

          <div class="anchoFranja" style="position: relative; top: -100%; left: 0%; overflow: hidden; background-color:transparent;"> <!-- background transparente para dejar ver el texto anterior -->  
            <div class="animatedBanner3" style="background-color:#7db700">
              <div class="textoInterior" style="transform: translateY(-15%);"  >
                
                <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Limpieza Higiene</h1>
                <p class="tamanoTextoProducto3">Soluciones Integrales</p>
                  <p class="margenBoton"><a  style="color: #7db700 " class="botonBlanco" href="<?php echo(base_url());?>index.php/limpieza">+ VER MÁS</a></p>
                
              </div>
               </div>
          </div>
          
          
          <div class="container">
                      
            <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  
                  <div class="animatedBanner2" >
                    
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_4B.jpg" >
                <img class="desaparece" style="transform-origin: center center; width: 100%; transform: translateY(-150%); " src="<?php echo(base_url());?>images/Banner_4A.jpg" >
                
            </div>
          </div>
        </div>
 <!-- Colocar desde aqui imagen repetida del primer banner -->  
         <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  <div class="animatedBanner4" >
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_3B.jpg" >
            </div>
          </div>
        </div>
<!-- Colocar hasta aqui imagen repetida del primer banner -->        
          </div>
        </div>
        
       
		  
		  <div class="carousel-item " >
<!-- Colocar desde aqui texto repetido del banner anterior -->
          <div class="anchoFranja" style="position: relative; top: 0%; left: 0%; overflow: hidden;   background-color:#7db700;">
              <div class="" style="background-color: #ffa400">
                <div class="desapareceTexto" style="transform: translateY(-15%);"  >
                
                     <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Limpieza Higiene</h1>
                <p class="tamanoTextoProducto3">Soluciones Integrales</p>
                  <p class="margenBoton"><a style="color: #7db700 " class="botonBlanco" href="<?php echo(base_url());?>index.php/limpieza">+ VER MÁS</a></p>
            
                </div>
              </div>
            </div>
  <!-- Colocar hasta aqui texto repetido del banner anterior -->    

          <div class="anchoFranja" style="position: relative; top: -100%; left: 0%; overflow: hidden; background-color:transparent;"> <!-- background transparente para dejar ver el texto anterior -->  
            <div class="animatedBanner3" style="background-color:#9163a6">
              <div class="textoInterior" style="transform: translateY(-15%);"  >
                
                <p class="tamanoTextoProducto2">Línea</p>
                <h1 class="tamanoTextoProducto">Seguridad Industrial</h1>
                <p class="tamanoTextoProducto3">Prevención de Riesgos</p>
                  <p class="margenBoton"><a style="color: #9163a6 " class="botonBlanco" href="<?php echo(base_url());?>index.php/industrial">+ VER MÁS</a></p>
                
              </div>
               </div>
          </div>
          
          
          <div class="container">
                      
            <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  
                  <div class="animatedBanner2" >
                    
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_5B.jpg" >
                <img class="desaparece" style="transform-origin: center center; width: 100%; transform: translateY(-150%); " src="<?php echo(base_url());?>images/Banner_5A.jpg" >
                
            </div>
          </div>
        </div>
 <!-- Colocar desde aqui imagen repetida del primer banner -->  
         <div class="carousel-caption" >
                <div class="innerBannerContainer">
                  <div class="animatedBanner4" >
                    <img  style="transform-origin: center center; width: 100%; transform: translateY(-50%);" src="<?php echo(base_url());?>images/Banner_4B.jpg" >
            </div>
          </div>
        </div>
<!-- Colocar hasta aqui imagen repetida del primer banner -->        
          </div>
        </div>
		  
		  
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

        
      </div>
     
    </div>

    
    

  </div>

</div>



  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

  <div class="container-fluid marketing">
			  
	<!-- desde aqui seccion para mobile --> 
		<div class="row mobileShow show-on-scroll " style="background-color: #eaeaea; padding-bottom: 3rem"> 
			
				<div class="col-12 seccion2" style="text-align: center;">
					<div class="row">
						<div class="col-2 col-md-3 "></div>
						<div class="col-8 col-md-6"><p style="color: #ffa400; font-size: 1.5rem; font-weight: bold; margin-top: 2.5rem">Calidad que</p>
				<p style="color: #f37021; font-size: 2.5rem; font-family: 'Playfair Display', serif; margin-top: -2rem">Asegura su éxito</p>
				<p style="color: white; font-size: 1rem;">Es nuestro principio brindarles nuestra mayor confianza y  
experiencia en cada paso y desición que su empresa requiera.</p>
						</div>
						<div class="col-2 col-md-3"></div>
					</div>
					
					
				<div style="height: 8rem"></div>
				</div>
				
			
	  	
	  
	  	<div class="row mobileShow show-on-scroll " style="background-color: #eaeaea; text-align: center; margin-top: -6rem"> 
			<div class="col-2 col-md-3"></div>
			<div class="col-8 col-md-6">
				<img width="70%" src="<?php echo(base_url());?>images/1.png">
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: bold; margin-top: 1.5rem; text-align: center">Quiénes Somos</p>
				<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; ">Hemos buscado proporcionar valores agregados innovadores que garanticen mejores costos sin sacrificar la calidad y liquidez para su compañía cumpliendo con sus expectativas y favoreciendo a la vez  sus metas.</p>
				
				<a class="botonNaranja" href="<?php echo(base_url());?>index.php/quienes">+ VER MÁS</a>
			</div>
			<div class="col-2 col-md-3"></div>
			
			
		 </div> 
	  
	  <div class="row mobileShow show-on-scroll " style="background-color: #eaeaea; text-align: center; margin-top: 3rem"> 
			<div class="col-2 col-md-3"></div>
			<div class="col-8 col-md-6">
				<img width="70%" src="<?php echo(base_url());?>images/2.png">
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: bold; margin-top: 1.5rem; text-align: center">Visítenos</p>
				<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; ">Siempre pensando en ustedes, aquí encontrarán las mejores sugerencias y consejos sobre la variedad de productos y servicios que ofrecemos.</p>
				<a class="botonNaranja" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">+ VER MÁS</a>

			</div>
			<div class="col-2 col-3"></div>
			
			
		 </div> 
			
		  <div class="row mobileShow show-on-scroll " style="background-color: #eaeaea; text-align: center; margin-top: 3rem"> 
			<div class="col-2 col-md-3"></div>
			<div class="col-8 col-md-6">
				<img width="70%" src="<?php echo(base_url());?>images/3.png">
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: bold; margin-top: 1.5rem; text-align: center">Contáctenos</p>
				<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; ">Si desea más información a cerca de nuestros productos y servicios, no dude en contactarse con nosotros, que con gusto lo atenderemos.</p>
					<a class="botonNaranja" href="<?php echo(base_url());?>index.php/contactenos">+ VER MÁS</a>
			</div>
			<div class="col-2 col-md-3"></div>
			
			
		 </div> 
	  
	  </div>
	  
		  <!--  
hasta aqui seccion para mobile
--> 	 
		  
<!--  
desde aqui seccion para desktop
--> 
	  <div style="clear: both"></div>
	  <div class="row desktopShow" style="background-color: #eaeaea;"> 
	  <div class="col-12">
		  <div class="row productBanner show-on-scroll p-6 seccion2" > 
		<div class="col-12">
		<div class="row" >
			<div class="col-md-2 col-lg-3"></div>
			<div class="col-md-8 col-lg-6" style=" text-align: center">
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: normal; margin-top: 6rem">Calidad que</p>
				<p style="color: #f37021; font-size: 3rem; font-family: 'Playfair Display', serif; margin-top: -1.7rem">Asegura su éxito</p>
				<p style="color: white; font-size: 1.2rem; font-weight: normal;">Es nuestro principio brindarles nuestra mayor confianza y  
experiencia en cada paso y desición que su empresa requiera.</p>
				<div style="height: 10rem"></div>
			</div>
			<div class="col-md-2 col-lg-3"></div>
		</div>
		
		
	</div>

    </div>
	  
	  <div class="row productBanner show-on-scroll p-6" style="margin-top: -6.5rem; ">
	  <div class="col-1 col-lg-2"></div>
		
		  <div class="col-3 col-lg-2 soloIpad" >
			<img width="110%" src="<?php echo(base_url());?>images/1.png">
			<p style="color: #f37021; font-size: 1.5rem; font-weight: normal; margin-top: 1.5rem; text-align: center">Quiénes Somos</p>
			<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; font-weight: normal;">Hemos buscado proporcionar valores agregados innovadores que garanticen mejores costos sin sacrificar la calidad y liquidez para su compañía cumpliendo con sus expectativas y favoreciendo a la vez  sus metas.</p>
			
		  </div>
		<div class="col-1 col-lg-1"></div>
		  
		<div class="col-3 col-lg-2">
			<img width="110%" src="<?php echo(base_url());?>images/2.png">
			<p style="color: #f37021; font-size: 1.5rem; font-weight: normal; margin-top: 1.5rem; text-align: center">Visítenos</p>
			<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; font-weight: normal;">Siempre pensando en ustedes, aquí encontrarán las mejores sugerencias y consejos sobre la variedad de productos y servicios que ofrecemos.</p> 
			
		</div>
		<div class="col-1 col-lg-1"></div>
		  
		<div class="col-3 col-lg-2">
			<img width="110%" src="<?php echo(base_url());?>images/3.png">
			<p style="color: #f37021; font-size: 1.5rem; font-weight: normal; margin-top: 1.5rem; text-align: center">Contáctenos</p>
			<p style="font-size: 1rem;  text-align: justify; text-justify: inter-word; font-weight: normal;">Si desea más información a cerca de nuestros productos y servicios, no dude en contactarse con nosotros, que con gusto lo atenderemos.</p> 
			
		</div>
		<div class="col-1 col-lg-2"></div>
	  </div>
	  
	   <div class="row productBanner show-on-scroll p-6" style="padding-bottom: 4rem;" >
	  <div class="col-1 col-lg-2 soloIpad"></div>
		<div class="col-3 col-lg-2">
			
			<a class="botonNaranja" href="<?php echo(base_url());?>index.php/quienes">+ VER MÁS</a>
		  </div>
		<div class="col-1 col-lg-1"></div>
		<div class="col-3 col-lg-2">
		
			<a class="botonNaranja" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">+ VER MÁS</a>
		</div>
		<div class="col-1 col-lg-1"></div>
		<div class="col-3 col-lg-2">
			
			<a class="botonNaranja" href="<?php echo(base_url());?>index.php/contactenos">+ VER MÁS</a>
		</div>
		<div class="col-1 col-lg-2"></div>
	  </div>
	  
		  </div>
		  
		  <!--  
			hasta aqui seccion para desktop
			--> 
	  </div>
    
    <div class="row productBanner show-on-scroll p-6 "> 
		<div class="col-12">
		<div class="row" >
			<div class="col-lg-3"></div>
			<div class="col-lg-6"  style=" text-align: center">
				<div style="height: 3rem"></div>
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: normal; margin-top: 2.5rem">Somos el</p>
				<p style="color: #f37021; font-size: 3rem; font-family: 'Playfair Display', serif; margin-top: -1.7rem">Aliado Estratégico</p>
				<p style="color: #ffa400; font-size: 1.5rem; font-weight: normal; margin-top: -1.7rem">de su Compañía</p>
				<p style=" font-size: 1.2rem; font-weight: normal;">Somos un socio indispensable dentro de su compañía, fielmente comprometido a enteder su negocio y lo que este precisa. </p>
				<div style="height: 3rem"></div>
			</div>
			<div class="col-lg-3"></div>
		</div>
		
		
	</div>

    </div>
	  
	  
	  <div class="desktopShow">
		<div class="row show-on-scroll"> 
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/1.jpg">
			</div>
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/2.jpg">
			</div>
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/3.jpg">
			</div>
		</div>
		  <div class="row show-on-scroll"> 
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/4.jpg">
			</div>
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/5.jpg">
			</div>
			<div class="col-4 nopadding">
				<img width="100%" src="<?php echo(base_url());?>images/seccion3/6.jpg">
			</div>
		</div>
	  </div>
	  
	  
			
				<div class="row show-on-scroll mobileShow" style="background-color: aqua">
					
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/1.jpg"></div>
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/2.jpg"></div>	
		   		</div>
	  
	  			<div class="row show-on-scroll mobileShow" style="background-color: aqua">
					
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/3.jpg"></div>
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/6.jpg"></div>
		   		</div>

	  			<div class="row show-on-scroll mobileShow" style="background-color: aqua">
					
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/5.jpg"></div>
						<div class="col-6 nopadding"><img width="100%" src="<?php echo(base_url());?>images/seccion3/4.jpg"></div>	
							
		   		</div>


		
			
	  </div>
	  
	  <div class="row show-on-scroll " style="margin-top: 6rem"> 
	  <div class="col-2 col-md-5 nopadding">
			
		</div>
		  
		<div class="col-8 col-md-2 nopadding">
			<a class="botonNaranja" href="<?php echo(base_url());?>index.php/quienes">+ VER MÁS</a>
		</div>
		<div class="col-2 col-md-5 nopadding">
			
		</div>
	  </div>
	
	 <div class="row show-on-scroll" style="margin-top: 6rem"> 

  	</div>
  </div>



	
	
	
	
	
	


