<div class="row margenSuperiorIpad desktopShow fade-in" style="height: 100vh; color: white; font-weight:bold; padding-top:4%; font-size: 1.5rem;  ">	
			
				<div class="col-1 col-lg-1"></div>
				<div class="col-4 col-lg-3">
					Acerca de Nosotros 
					<ul style="font-size: 1.3rem; font-weight: 300; list-style-type: none; padding: 0rem; padding-top: 2rem">
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem"  src="<?php echo(base_url());?>images/1_Quienes_Somos.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/quienes">Quiénes Somos</a></li>
						<li style="margin-top: 2rem" ><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/2_Visitenos.png"><a class="linkMenu" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">Visítenos</a></li>
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/3_Contactenos.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/contactenos">Contáctenos</a></li>
					</ul>
				</div>
	
				<div class="col-1 col-lg-1"></div>
				<div class="col-4 col-lg-4 soloIpad">
					Productos
					<ul style="font-size: 1.3rem; font-weight: 300; list-style-type: none; padding: 0rem; padding-top: 2rem;">
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem"  src="<?php echo(base_url());?>images/4_Linea_Papel.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/papelCarton">Línea Papel Cartón</a></li>
						<li style="margin-top: 2rem" ><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/5_Linea_Chrysal.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/chrysal">Línea Chrysal</a></li>
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/6_Linea_Empaque.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/empaque">Línea Empaque</a></li>
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/7_Linea_Limpieza.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/limpieza">Línea Limpieza Higiene</a></li>
						<li style="margin-top: 2rem"><img style="margin-right: 1rem; width: 4rem" src="<?php echo(base_url());?>images/8_Linea_SegInustrial.png"><a class="linkMenu" href="<?php echo(base_url());?>index.php/industrial">Línea Seguridad Industrial</a></li>
					</ul>
				</div>
				
				<div class="col-1 col-lg-2" style="text-align: right">
					
					<ul style="font-size: 1.3rem; font-weight: 300; list-style-type: none; padding-top: 5rem">
						<li style="margin-top: 2rem"><a  class="facebookIcon" href="https://www.facebook.com/megastockec" target="_blank"><img style="margin-right: 1rem; width: 2rem"  src="<?php echo(base_url());?>images/Facebook.svg"></a></li>
						<li style="margin-top: 2rem" ><a class="InstagramIcon"   href="https://www.instagram.com/megastock_megaecuador/" target="_blank"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/Instagram.svg"></a></li>
						<li style="margin-top: 2rem"><a  class="WhatsappIcon"  href="https://bit.ly/3adVRmh" target="_blank"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/Whatsapp.svg"></a></li>
					</ul>
					
				</div>
				<div class="col-1 col-lg-1"></div>
		</div>
	
		<div class="row mobileShow mb-5" style="color: white; font-weight:bold; padding-top:10%; font-size: 1rem; overflow-y: hidden;">	
			<div class="col-1"></div>
			<div class="col-10">
			
				Acerca de Nosotros 
					<ul style="font-weight: normal; list-style-type: none; padding-top: 0rem; padding-left: 0;">
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem"  src="<?php echo(base_url());?>images/1_Quienes_Somos.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/quienes">Quiénes Somos</a></li>
						<li style="margin-top: 0.7rem" ><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/2_Visitenos.png"><a class="linkMenuMobile" href="https://www.instagram.com/megastock_megaecuador/" target="_blank">Visítenos</a></li>
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/3_Contactenos.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/contactenos">Contáctenos</a></li>
					</ul>
				
				Productos
					<ul style="font-size: 1.3rem; font-weight: normal; list-style-type: none; padding-top: 0rem; padding-left: 0;">
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem"  src="<?php echo(base_url());?>images/4_Linea_Papel.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/papelCarton">Línea Papel Cartón</a></li>
						<li style="margin-top: 0.7rem" ><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/5_Linea_Chrysal.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/chrysal">Línea Chrysal</a></li>
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/6_Linea_Empaque.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/empaque">Línea Empaque</a></li>
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/7_Linea_Limpieza.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/limpieza">Línea Limpieza Higiene</a></li>
						<li style="margin-top: 0.7rem"><img style="margin-right: 1rem; width: 2rem" src="<?php echo(base_url());?>images/8_Linea_SegInustrial.png"><a class="linkMenuMobile" href="<?php echo(base_url());?>index.php/industrial">Línea Seguridad Industrial</a></li>
					</ul>
				
				
				
				
				
				
			</div>
			<div class="col-1"></div>
			<div class="container-fluid">
			<div class="row" style="border-top: 1px solid #6b6b6b; margin-top: 1rem "></div> 
				<div class="row" style="padding-top: 1rem; padding-bottom: 1rem;">
					<div class="col-2"></div>
					<div class="col-8" style=" text-align: center">

						<ul style="list-style-type: none">
							<li style="display: inline-block; margin-left: -2rem"><a class="facebookIcon" target="_blank"  href="https://www.facebook.com/megastockec" > <img  width="30rem" src="<?php echo(base_url());?>images/Facebook.svg"></a></li>
							<li style="display: inline-block; padding-left: 2rem"><a class="InstagramIcon" target="_blank" href="https://www.instagram.com/megastock_megaecuador/"> <img width="30rem" src="<?php echo(base_url());?>images/Instagram.svg"> </a></li>
							<li style="display: inline-block; padding-left: 2rem"><a class="WhatsappIcon" target="_blank"  href="https://bit.ly/38hbAkQ"> <img width="30rem" src="<?php echo(base_url());?>images/Whatsapp.svg"></a></li>
						</ul>

					</div>
					<div class="col-2"></div>
				</div>
				
			</div>
		</div>


</div>
	
	
    </nav>
	
	
</div>