<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

</header>

<main role="main" style="display:none;" id="myDiv">
	
<div class="container-fluid" style="background-color: #eaeaea">
	
	<div class="row show-on-scroll" style="margin-top: 8rem; margin-bottom: 8rem;">
		<div class="col-md-1"></div>
		<div class="col-md-10" style="text-align: center" >
			<img class="img-fluid"  src="<?php echo(base_url());?>images/notFound.png"></div>
		<div class="col-md-1"></div>
	</div>
	
	<div class="row mt-5"></div>
	
	

</div>

</body>